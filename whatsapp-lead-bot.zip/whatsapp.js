/**
 * Baileys WhatsApp Multi-Device Client
 * Manages WebSocket connection, live QR generation, auto-reconnect, and AI reply handler
 */

const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const pino = require('pino');
const QRCode = require('qrcode');
const path = require('path');
const ai = require('./ai');
const scraper = require('./scraper');

const AUTH_DIR = path.join(__dirname, 'auth_info_baileys');

let sock = null;
let currentQrCodeDataUrl = null;
let isConnectedState = false;
let userPhone = null;

// Store in-memory conversation history for contextual AI replies
const conversationHistories = new Map();

async function initWhatsApp(onReadyCallback) {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);

  sock = makeWASocket({
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: true, // Also prints in console
    browser: ['Bemisaal Cloud Bot', 'Chrome', '124.0.0']
  });

  // Save auth state changes
  sock.ev.on('creds.update', saveCreds);

  // Connection update event
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      try {
        currentQrCodeDataUrl = await QRCode.toDataURL(qr);
        console.log('📲 [WhatsApp QR] New QR Code generated! Open /qr in browser to scan.');
      } catch (err) {
        console.error('Failed to generate QR data URL:', err);
      }
    }

    if (connection === 'close') {
      isConnectedState = false;
      currentQrCodeDataUrl = null;
      const shouldReconnect = (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log(`⚠️ [WhatsApp] Connection closed. Reason: ${lastDisconnect?.error?.message}. Reconnecting: ${shouldReconnect}`);
      
      if (shouldReconnect) {
        setTimeout(() => initWhatsApp(onReadyCallback), 5000);
      } else {
        console.log('❌ [WhatsApp] Logged out. Please rescan QR code.');
      }
    } else if (connection === 'open') {
      isConnectedState = true;
      currentQrCodeDataUrl = null;
      userPhone = sock.user?.id ? sock.user.id.split(':')[0] : 'Connected';
      console.log(`\n🎉 [WhatsApp] Connected successfully as +${userPhone}! Bot is LIVE.\n`);
      if (onReadyCallback) onReadyCallback();
    }
  });

  // Incoming message event (Lead replies)
  sock.ev.on('messages.upsert', async (m) => {
    try {
      const msg = m.messages?.[0];
      if (!msg || !msg.message || msg.key.fromMe) return;

      const senderJid = msg.key.remoteJid;
      // Only process direct user chats (ignore groups / status broadcasts)
      if (!senderJid.endsWith('@s.whatsapp.net')) return;

      const senderPhone = senderJid.replace('@s.whatsapp.net', '');
      const incomingText = msg.message.conversation ||
                           msg.message.extendedTextMessage?.text ||
                           msg.message.imageMessage?.caption || '';

      if (!incomingText.trim()) return;

      console.log(`📩 [Lead Reply from ${senderPhone}]: "${incomingText}"`);

      // Update lead status in DB
      scraper.updateLeadStatus(senderPhone, 'replied');

      // Human-like typing indicator
      await sock.sendPresenceUpdate('composing', senderJid);
      await new Promise(r => setTimeout(r, 2000 + Math.random() * 2000));

      // Retrieve past chat history
      const history = conversationHistories.get(senderPhone) || [];
      history.push({ role: 'user', content: incomingText });

      // Generate AI doctor reply via Groq
      const aiReply = await ai.handleIncomingMessage(senderPhone, incomingText, history);

      if (aiReply) {
        await sock.sendMessage(senderJid, { text: aiReply });
        history.push({ role: 'assistant', content: aiReply });
        conversationHistories.set(senderPhone, history.slice(-10));
        console.log(`🤖 [AI Replied to ${senderPhone}]: "${aiReply}"`);
      }
    } catch (msgErr) {
      console.error('Error handling incoming message:', msgErr);
    }
  });

  return sock;
}

/**
 * Send Text Message to a lead JID
 */
async function sendTextMessage(jid, text) {
  if (!sock || !isConnectedState) {
    console.warn('Cannot send message: WhatsApp socket is not connected');
    return false;
  }

  try {
    // Show realistic typing presence (3.5 to 6.5s) to look 100% human to WhatsApp telemetry
    await sock.sendPresenceUpdate('composing', jid);
    const typingDelay = Math.floor(3500 + Math.random() * 3000);
    await new Promise(r => setTimeout(r, typingDelay));
    
    await sock.sendMessage(jid, { text: text });
    await sock.sendPresenceUpdate('paused', jid);
    return true;
  } catch (err) {
    console.error(`Error sending message to ${jid}:`, err.message);
    return false;
  }
}

function getQrCodeDataUrl() {
  return currentQrCodeDataUrl;
}

function isConnected() {
  return isConnectedState;
}

function getConnectedNumber() {
  return userPhone;
}

module.exports = {
  initWhatsApp,
  sendTextMessage,
  getQrCodeDataUrl,
  isConnected,
  getConnectedNumber
};

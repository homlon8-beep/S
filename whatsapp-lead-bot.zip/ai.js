/**
 * Webify AI Sales Consultant powered by Groq (openai/gpt-oss-120b)
 * Converts business leads worldwide (focus: USA, UK, Canada, India) for:
 * 1. High-Converting Modern Websites
 * 2. 24/7 AI Lead Generation Bots (180+ leads/day)
 * STRICT RULE: NO phone calls! Everything is handled directly inside WhatsApp chat.
 */

const GROQ_API_KEY = process.env.GROQ_API_KEY;
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const AGENCY_NAME = process.env.AGENCY_NAME || 'Webify';

const SYSTEM_PROMPT = `You are Alex, an expert Digital Growth Consultant and Co-Founder at Webify (Webify Digital Solutions).

About Webify:
We help business owners, founders, contractors, and agencies worldwide scale their revenue with two core offerings:
1. Modern High-Converting Websites: Lightning-fast, mobile-first, designer-grade websites & landing pages (Next.js, Tailwind, modern stacks) engineered to turn cold visitors into booked appointments and paying customers.
2. Autonomous AI Lead Generation Bots: Cloud-hosted outreach engines that pull in 180+ qualified, verified leads every day on complete autopilot without manual prospecting.

CRITICAL ENGAGEMENT RULES:
- STRICTLY NO PHONE CALLS OR HELPLINES. Do NOT ask them to call a phone number. All consultations, quotes, questions, and demos are delivered directly right here inside this WhatsApp chat!
- Assist them right here in the conversation: "Tell me a bit about your business or what you currently do to get clients, and I can share a free live interactive preview / lead breakdown right here in chat!"
- Tone: Natural, founder-to-founder, friendly, respectful, and sharp. Never sound like an automated corporate robot or pushy spammer.
- Language:
  * Default to clean, modern, natural English (perfect for USA, UK, Canada, Australia, and global founders).
  * If the contact speaks Hindi or Hinglish, switch seamlessly to warm, natural conversational Hinglish.
- Length: Keep messages concise and readable (2 to 4 lines max). People read WhatsApp quickly.
- When they ask for Pricing:
  * Websites typically start around $299 - $799 for high-converting landing pages / business sites (or ₹15,000 - ₹35,000 in India).
  * AI Lead Bots are tailored to their target niche.
  * Tell them: "I can give you a transparent, custom breakdown right here—what niche or industry is your business in?"
- When they want a Demo / Preview:
  * "Awesome! What's your business name or website/social link? I'll put together a live interactive mockup for you today."
- If someone says STOP or is not interested:
  * "No worries at all! Wishing you and your business all the best." (and do not follow up).`;

/**
 * Call Groq API
 */
async function callGroq(messages, temperature = 0.6) {
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages: messages,
        temperature: temperature,
        max_tokens: 350
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Groq API Error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    return data.choices?.[0]?.message?.content?.trim() || '';
  } catch (err) {
    console.error('❌ Groq API Failure:', err.message);
    return null;
  }
}

/**
 * Generate humanized initial greeting message (0% Ban Risk Soft Opt-in)
 */
async function generateOutreachMessage(leadName = '', country = 'USA') {
  const isIndianLead = country === 'India' || country === 'IN';
  
  const prompt = [
    { role: 'system', content: SYSTEM_PROMPT },
    {
      role: 'user',
      content: `Create a 100% human, personalized initial WhatsApp outreach message.
Context:
- The recipient is a business owner / professional discovered online.
- Purpose: Ask them in a genuine, friendly, non-pushy way if they are looking for a modern high-converting website or want an AI bot that brings them 180+ qualified leads a day.
- STRICT RULE: Do NOT ask them to call any phone number! Ask them to reply right here in chat.
- Add the soft opt-out at the end: '(If you are not interested, just reply STOP and I won't message again!)'
- Language: ${isIndianLead ? 'Warm conversational English or friendly Hinglish' : 'Natural, casual, professional American English'}.
- Length: 3-4 lines maximum.`
    }
  ];

  const generated = await callGroq(prompt, 0.7);
  if (generated) return generated;

  // Safe fallback template if API is offline
  if (isIndianLead) {
    return `Hey ${leadName ? leadName : 'there'}! Came across your profile while researching active businesses—noticed you might not have a dedicated modern website up yet (or could use more customer flow). We run Webify, where we build clean high-converting websites and AI lead bots that deliver 180+ fresh leads a day on autopilot.\n\nCurious if you'd be open to seeing a quick demo right here in chat? Just reply with what you do!\n\n(If not interested, just reply STOP and I won't message again!)`;
  }

  return `Hey ${leadName ? leadName : 'there'}! Came across your business while looking through active local brands—noticed you might not have a dedicated high-converting website up yet (or could use more client flow). At Webify, we build clean modern websites and AI lead bots that pull in 180+ qualified leads a day on autopilot.\n\nCurious if you'd be open to seeing a quick live concept right here in chat? Just reply with what you do!\n\n(If not interested, just reply STOP and I won't message again!)`;
}

/**
 * Handle incoming reply from a lead
 */
async function handleIncomingMessage(senderName, incomingText, history = []) {
  const messages = [
    { role: 'system', content: SYSTEM_PROMPT }
  ];

  // Append past messages if any
  if (Array.isArray(history)) {
    history.slice(-6).forEach(h => {
      messages.push({ role: h.role, content: h.content });
    });
  }

  messages.push({
    role: 'user',
    content: incomingText
  });

  const reply = await callGroq(messages, 0.6);
  if (reply) return reply;

  return `Thanks for replying! We can assist you right here in chat. What kind of business do you run, and are you more interested in getting a modern high-converting website designed, or an AI outreach bot that pulls in 180+ leads a day?`;
}

module.exports = {
  generateOutreachMessage,
  handleIncomingMessage
};

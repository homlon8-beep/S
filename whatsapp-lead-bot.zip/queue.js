/**
 * Humanized Queue Dispatcher
 * Rule: 1 msg every 2 minutes (10 msgs per batch) -> 30-minute cool-down break
 * Goal: 120-150 safe leads per day without triggering WhatsApp spam filters
 */

const ai = require('./ai');
const scraper = require('./scraper');

const BATCH_SIZE = parseInt(process.env.BATCH_SIZE || '10', 10);
const DELAY_BETWEEN_MSGS_MS = parseInt(process.env.DELAY_BETWEEN_MSGS_MS || '120000', 10); // ~2 minutes
const BATCH_BREAK_MS = parseInt(process.env.BATCH_BREAK_MS || '1200000', 10); // 20 minutes

let isRunning = false;
let isPaused = false;
let currentBatchCount = 0;
let totalSentSession = 0;
let nextActionTime = null;
let currentStatus = 'Idle';

function getQueueState() {
  const db = scraper.loadDatabase();
  const queuedCount = db.leads.filter(l => l.status === 'queued').length;
  const sentCount = db.leads.filter(l => l.status === 'sent').length;

  return {
    isRunning,
    isPaused,
    currentStatus,
    currentBatchCount,
    batchSize: BATCH_SIZE,
    totalSentSession,
    totalSentDb: sentCount,
    queuedRemaining: queuedCount,
    nextActionTime: nextActionTime ? new Date(nextActionTime).toLocaleTimeString('en-IN') : null
  };
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Start the worker loop
 */
async function startQueueWorker(whatsappClient) {
  if (isRunning) return;
  isRunning = true;
  console.log(`🚀 [Queue Worker] Started! Formula: 1 msg/2 mins (Batch of 10) -> 30 min break.`);

  while (isRunning) {
    if (isPaused) {
      currentStatus = 'Paused by User';
      await sleep(5000);
      continue;
    }

    // Check if WhatsApp is connected
    if (!whatsappClient || !whatsappClient.isConnected()) {
      currentStatus = 'Waiting for WhatsApp Web QR connection...';
      await sleep(10000);
      continue;
    }

    // Get next lead
    let batch = scraper.getQueuedLeads(1);
    if (batch.length === 0) {
      currentStatus = 'Queue Empty: Scraping fresh business leads (100% Free)...';
      console.log('🔍 [Auto-Scraper] Queue is empty! Automatically triggering Free Web Scraper (Zero API cost)...');
      try {
        await scraper.triggerFreeWebScraper({ targetCount: 15 });
      } catch (err) {
        console.error('Free Auto-scraper error:', err.message);
        // Fallback to Apify only if free scraper encountered an error and token exists
        if (process.env.APIFY_API_TOKEN) {
          console.log('⚠️ [Auto-Scraper] Trying Apify fallback...');
          try { await scraper.triggerApifyLeadDiscovery(); } catch (e) {}
        }
      }
      batch = scraper.getQueuedLeads(1);
      if (batch.length === 0) {
        console.log('⏳ [Auto-Scraper] Waiting 60s before next auto-scrape cycle...');
        await sleep(60000);
        continue;
      }
    }

    const lead = batch[0];

    // Check if batch limit (10 msgs) reached -> Take 20 min break
    if (currentBatchCount >= BATCH_SIZE) {
      currentStatus = `Batch of ${BATCH_SIZE} complete. Taking 20-min break for WhatsApp safety...`;
      nextActionTime = Date.now() + BATCH_BREAK_MS;
      console.log(`\n☕ [Queue Worker] 10 messages sent! Taking 20-minute cool-down break until ${new Date(nextActionTime).toLocaleTimeString('en-IN')}...\n`);
      
      await sleep(BATCH_BREAK_MS);
      
      currentBatchCount = 0;
      console.log(`⚡ [Queue Worker] Cool-down break finished! Resuming next batch...`);
    }

    // Prepare personalized message via Groq AI
    currentStatus = `Generating AI outreach for ${lead.phone} (${lead.country || 'USA'})...`;
    console.log(`🤖 [Groq AI] Generating personalized outreach for ${lead.phone} (${lead.country || 'USA'})...`);
    const outreachText = await ai.generateOutreachMessage(lead.name, lead.country || 'USA');

    // Send via WhatsApp
    currentStatus = `Sending message to ${lead.phone}...`;
    try {
      const sent = await whatsappClient.sendTextMessage(lead.jid, outreachText);
      if (sent) {
        scraper.updateLeadStatus(lead.phone, 'sent');
        currentBatchCount++;
        totalSentSession++;
        console.log(`✅ [Sent ${currentBatchCount}/${BATCH_SIZE}] To ${lead.phone}. Total session: ${totalSentSession}`);
      } else {
        scraper.updateLeadStatus(lead.phone, 'failed', 'Socket send failure');
      }
    } catch (sendErr) {
      console.error(`❌ [Send Error] Failed to send to ${lead.phone}:`, sendErr.message);
      scraper.updateLeadStatus(lead.phone, 'failed', sendErr.message);
    }

    // Dynamic Humanized Jitter: 95s to 145s (averaging ~2 mins) so WhatsApp never detects a robotic pattern
    const humanJitterDelay = Math.floor(95000 + Math.random() * 50000);
    currentStatus = `Waiting ${Math.round(humanJitterDelay / 1000)}s before next lead (human jitter)...`;
    nextActionTime = Date.now() + humanJitterDelay;
    console.log(`⏳ [Human Jitter] Sleeping ${Math.round(humanJitterDelay / 1000)}s before next message...`);
    await sleep(humanJitterDelay);
  }
}

function pauseQueue() {
  isPaused = true;
  console.log('⏸️ [Queue Worker] Paused');
}

function resumeQueue() {
  isPaused = false;
  console.log('▶️ [Queue Worker] Resumed');
}

module.exports = {
  startQueueWorker,
  pauseQueue,
  resumeQueue,
  getQueueState
};
